
<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/db.php';

// Escape output safely
function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Delete a member
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_member'])) {
    $member_id = (int) ($_POST['member_id'] ?? 0);

    if ($member_id > 0) {
        try {
            $stmt = $conn->prepare(
                "DELETE FROM members WHERE member_id = ?"
            );
            $stmt->execute([$member_id]);

            header("Location: index.php?message=deleted");
            exit;
        } catch (PDOException $e) {
            header("Location: index.php?message=error");
            exit;
        }
    }

    header("Location: index.php?message=error");
    exit;
}

// Search members
$search = trim($_GET['search'] ?? '');

if ($search !== '') {
    $stmt = $conn->prepare("
        SELECT * FROM members
        WHERE member_number LIKE ?
        OR full_name LIKE ?
        OR email LIKE ?
        OR phone LIKE ?
        ORDER BY member_id DESC
    ");

    $term = "%$search%";
    $stmt->execute([$term, $term, $term, $term]);
} else {
    $stmt = $conn->query("
        SELECT * FROM members
        ORDER BY member_id DESC
    ");
}

$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members Management | Library System</title>
    <link rel="stylesheet" href="../assets/css/library-theme.css">

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f5f2fa;
            color: #302640;
        }

        .sidebar {
            position: fixed;
            width: 250px;
            height: 100vh;
            background: #35135f;
            color: white;
            padding: 35px 20px;
        }

        .sidebar h2 {
            font-size: 23px;
            margin-bottom: 45px;
            line-height: 1.4;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 16px;
            margin-bottom: 12px;
            border-radius: 8px;
            font-size: 16px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #7546b8;
        }

        .main {
            margin-left: 250px;
            padding: 45px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 35px;
        }

        .header h1 {
            color: #35135f;
            font-size: 32px;
            margin-bottom: 8px;
        }

        .header p {
            color: #756b80;
            font-size: 16px;
        }

        .add-btn {
            background: #51218a;
            color: white;
            text-decoration: none;
            padding: 16px 24px;
            border-radius: 9px;
            font-weight: bold;
            font-size: 16px;
        }

        .add-btn:hover {
            background: #7546b8;
        }

        .message {
            padding: 17px 20px;
            border-radius: 8px;
            margin-bottom: 22px;
            font-size: 15px;
        }

        .success {
            background: #e4f6e9;
            color: #176b32;
        }

        .error {
            background: #ffe7e7;
            color: #a02020;
        }

        .content-card {
            background: white;
            padding: 30px;
            border-radius: 14px;
            box-shadow: 0 5px 22px rgba(53, 19, 95, 0.07);
            width: 100%;
        }

        .search-area {
            display: flex;
            gap: 12px;
            margin-bottom: 28px;
            flex-wrap: wrap;
        }

        .search-area input {
            flex: 1;
            min-width: 230px;
            padding: 16px;
            border: 1px solid #d9cde8;
            border-radius: 8px;
            font-size: 16px;
            outline: none;
        }

        .search-area input:focus {
            border-color: #7546b8;
        }

        .search-area button {
            background: #7546b8;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 15px 25px;
            cursor: pointer;
            font-size: 16px;
        }

        .search-area .clear-btn {
            background: #eee8f5;
            color: #51218a;
            text-decoration: none;
            padding: 15px 22px;
            border-radius: 8px;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        th {
            background: #f0eaf8;
            color: #35135f;
            text-align: left;
            padding: 18px 15px;
            font-size: 15px;
        }

        td {
            padding: 18px 15px;
            border-bottom: 1px solid #eee8f5;
            font-size: 14px;
        }

        tr:hover td {
            background: #fcfaff;
        }

        .status {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: capitalize;
        }

        .active-status {
            background: #e4f6e9;
            color: #176b32;
        }

        .inactive-status {
            background: #ffe7e7;
            color: #a02020;
        }

        .actions {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .edit-btn,
        .delete-btn {
            border: none;
            padding: 9px 13px;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-size: 13px;
        }

        .edit-btn {
            background: #eee8f5;
            color: #51218a;
        }

        .delete-btn {
            background: #ffe7e7;
            color: #a02020;
        }

        .empty {
            text-align: center;
            padding: 45px;
            color: #756b80;
            font-size: 16px;
        }

        @media (max-width: 800px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .sidebar h2 {
                margin-bottom: 15px;
            }

            .main {
                margin-left: 0;
                padding: 20px;
            }

            .header h1 {
                font-size: 26px;
            }

            .content-card {
                padding: 18px;
            }
        }
    </style>
</head>

<body>

<aside class="sidebar">
    <h2>Library Management System</h2>

    <a href="../dashboard.php">Dashboard</a>
    <a href="../books/index.php">Books Management</a>
    <a href="index.php" class="active">Members Management</a>
    <a href="../loans/index.php">Borrowing Records</a>
    <a href="../logout.php">Logout</a>
</aside>

<main class="main">

    <div class="header">
        <div>
            <h1>Members Management</h1>
            <p>Register, search and manage library members.</p>
        </div>

        <a href="add.php" class="add-btn">+ Add New Member</a>
    </div>

    <?php if (($_GET['message'] ?? '') === 'deleted'): ?>
        <div class="message success">
            Member deleted successfully.
        </div>
    <?php elseif (($_GET['message'] ?? '') === 'error'): ?>
        <div class="message error">
            This member could not be deleted. They may have borrowing records.
        </div>
    <?php endif; ?>

    <section class="content-card">

        <form method="GET" action="index.php" class="search-area">
            <input
                type="text"
                name="search"
                placeholder="Search by member number, name, email or phone..."
                value="<?= e($search) ?>"
            >

            <button type="submit">Search Members</button>

            <?php if ($search !== ''): ?>
                <a href="index.php" class="clear-btn">Clear Search</a>
            <?php endif; ?>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Member Number</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Registration Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($members) > 0): ?>

                        <?php foreach ($members as $index => $member): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td><?= e($member['member_number']) ?></td>
                                <td><?= e($member['full_name']) ?></td>
                                <td><?= e($member['email']) ?></td>
                                <td><?= e($member['phone']) ?></td>
                                <td><?= e($member['registration_date']) ?></td>

                                <td>
                                    <?php
                                    $isActive = strtolower($member['status']) === 'active';
                                    ?>
                                    <span class="status <?= $isActive ? 'active-status' : 'inactive-status' ?>">
                                        <?= e($member['status']) ?>
                                    </span>
                                </td>

                                <td>
                                    <div class="actions">
                                        <a
                                            href="edit.php?id=<?= (int) $member['member_id'] ?>"
                                            class="edit-btn"
                                        >Edit</a>

                                        <form method="POST" action="index.php"
                                              onsubmit="return confirm('Are you sure you want to delete this member?');">
                                            <input
                                                type="hidden"
                                                name="member_id"
                                                value="<?= (int) $member['member_id'] ?>"
                                            >

                                            <button
                                                type="submit"
                                                name="delete_member"
                                                class="delete-btn"
                                            >Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="empty">
                                No members found. Click "Add New Member" to register a member.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </section>

</main>

</body>
</html>
