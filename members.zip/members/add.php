
<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/db.php';

$errors = [];

$member_number = '';
$full_name = '';
$email = '';
$phone = '';
$address = '';
$registration_date = date('Y-m-d');
$status = 'active';

// Escape output safely
function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $member_number = trim($_POST['member_number'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $registration_date = trim($_POST['registration_date'] ?? '');
    $status = trim($_POST['status'] ?? '');

    // Server-side validation
    if ($member_number === '') {
        $errors[] = 'Member number is required.';
    }

    if ($full_name === '') {
        $errors[] = 'Full name is required.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }

    if ($registration_date === '') {
        $errors[] = 'Registration date is required.';
    } else {
        $date = DateTime::createFromFormat('Y-m-d', $registration_date);

        if (!$date || $date->format('Y-m-d') !== $registration_date) {
            $errors[] = 'Enter a valid registration date.';
        }
    }

    if (!in_array($status, ['active', 'inactive'], true)) {
        $errors[] = 'Select a valid member status.';
    }

    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("
                INSERT INTO members
                (
                    member_number,
                    full_name,
                    email,
                    phone,
                    address,
                    registration_date,
                    status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $member_number,
                $full_name,
                $email,
                $phone,
                $address,
                $registration_date,
                $status
            ]);

            header('Location: index.php?message=added');
            exit;

        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $errors[] = 'This member number or email address already exists.';
            } else {
                $errors[] = 'Unable to register this member. Please check the database and try again.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Member | Library Management System</title>
    <link rel="stylesheet" href="../assets/css/library-theme.css">

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f5f2fa;
            color: #302640;
        }

        .sidebar {
            position: fixed;
            width: 250px;
            height: 100vh;
            background: #35135f;
            color: white;
            padding: 35px 20px;
        }

        .sidebar h2 {
            font-size: 23px;
            margin-bottom: 45px;
            line-height: 1.4;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 16px;
            margin-bottom: 12px;
            border-radius: 8px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #7546b8;
        }

        .main {
            margin-left: 250px;
            padding: 45px;
        }

        .page-heading {
            margin-bottom: 30px;
        }

        .page-heading h1 {
            color: #35135f;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .page-heading p {
            color: #756b80;
            font-size: 16px;
        }

        .form-card {
            width: 100%;
            max-width: 1450px;
            background: white;
            padding: 45px;
            border-radius: 14px;
            box-shadow: 0 5px 22px rgba(53, 19, 95, 0.07);
        }

        .form-card h2 {
            color: #51218a;
            font-size: 23px;
            margin-bottom: 30px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 28px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 11px;
        }

        .form-group.full {
            grid-column: 1 / -1;
        }

        label {
            color: #35135f;
            font-weight: bold;
            font-size: 15px;
        }

        input, select, textarea {
            width: 100%;
            padding: 17px;
            min-height: 58px;
            border: 1px solid #d9cde8;
            border-radius: 8px;
            font-size: 16px;
            background: white;
            outline: none;
        }

        textarea {
            min-height: 115px;
            resize: vertical;
        }

        input:focus, select:focus, textarea:focus {
            border-color: #7546b8;
            box-shadow: 0 0 0 3px rgba(117, 70, 184, 0.1);
        }

        .buttons {
            display: flex;
            gap: 15px;
            margin-top: 35px;
            flex-wrap: wrap;
        }

        .save-btn {
            background: #51218a;
            color: white;
            border: none;
            padding: 17px 30px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .save-btn:hover {
            background: #7546b8;
        }

        .cancel-btn {
            background: #eee8f5;
            color: #51218a;
            padding: 17px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
        }

        .errors {
            background: #ffe7e7;
            color: #a02020;
            padding: 18px 25px;
            border-radius: 8px;
            margin-bottom: 25px;
        }

        .errors ul {
            margin-left: 20px;
        }

        .errors li {
            margin: 6px 0;
        }

        @media (max-width: 800px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .sidebar h2 {
                margin-bottom: 15px;
            }

            .main {
                margin-left: 0;
                padding: 20px;
            }

            .form-card {
                padding: 22px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-group.full {
                grid-column: auto;
            }
        }
    </style>
</head>

<body>

<aside class="sidebar">
    <h2>Library Management System</h2>

    <a href="../dashboard.php">Dashboard</a>
    <a href="../books/index.php">Books Management</a>
    <a href="index.php" class="active">Members Management</a>
    <a href="../loans/index.php">Borrowing Records</a>
    <a href="../logout.php">Logout</a>
</aside>

<main class="main">

    <div class="page-heading">
        <h1>Add New Member</h1>
        <p>Enter the details below to register a library member.</p>
    </div>

    <section class="form-card">

        <h2>Member Information</h2>

        <?php if (!empty($errors)): ?>
            <div class="errors">
                <strong>Please correct the following:</strong>

                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= e($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="add.php">

            <div class="form-grid">

                <div class="form-group">
                    <label for="member_number">Member Number *</label>

                    <input
                        type="text"
                        id="member_number"
                        name="member_number"
                        placeholder="Example: MEM001"
                        value="<?= e($member_number) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="full_name">Full Name *</label>

                    <input
                        type="text"
                        id="full_name"
                        name="full_name"
                        placeholder="Enter member's full name"
                        value="<?= e($full_name) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="email">Email Address *</label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="member@example.com"
                        value="<?= e($email) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>

                    <input
                        type="tel"
                        id="phone"
                        name="phone"
                        placeholder="Enter phone number"
                        value="<?= e($phone) ?>"
                    >
                </div>

                <div class="form-group full">
                    <label for="address">Physical Address</label>

                    <textarea
                        id="address"
                        name="address"
                        placeholder="Enter member's address"
                    ><?= e($address) ?></textarea>
                </div>

                <div class="form-group">
                    <label for="registration_date">Registration Date *</label>

                    <input
                        type="date"
                        id="registration_date"
                        name="registration_date"
                        value="<?= e($registration_date) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="status">Member Status *</label>

                    <select id="status" name="status" required>
                        <option value="active"
                            <?= $status === 'active' ? 'selected' : '' ?>>
                            Active
                        </option>

                        <option value="inactive"
                            <?= $status === 'inactive' ? 'selected' : '' ?>>
                            Inactive
                        </option>
                    </select>
                </div>

            </div>

            <div class="buttons">
                <button type="submit" class="save-btn">
                    Save Member
                </button>

                <a href="index.php" class="cancel-btn">
                    Cancel
                </a>
            </div>

        </form>

    </section>

</main>

</body>
</html>
