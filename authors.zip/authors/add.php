
<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/db.php';

$author_name = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $author_name = trim($_POST['author_name'] ?? '');

    if ($author_name === '') {
        $error = 'Please enter the author name.';
    } elseif (mb_strlen($author_name) > 150) {
        $error = 'Author name must not exceed 150 characters.';
    } else {
        try {
            $stmt = $conn->prepare(
                "INSERT INTO authors (author_name) VALUES (:author_name)"
            );

            $stmt->execute([
                ':author_name' => $author_name
            ]);

            header('Location: index.php');
            exit();

        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $error = 'This author already exists.';
            } else {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Author</title>
    <link rel="stylesheet" href="../assets/css/library-theme.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f2fa;
            padding: 30px;
        }

        .container {
            max-width: 500px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        h2 {
            color: #35135f;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button, a {
            padding: 11px 17px;
            background: #51218a;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        a {
            background: #666;
        }

        .error {
            background: #fce8e6;
            color: #a12622;
            padding: 12px;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>Add New Author</h2>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="add.php">

        <label for="author_name">Author Name</label>

        <input
            type="text"
            id="author_name"
            name="author_name"
            maxlength="150"
            value="<?= htmlspecialchars($author_name) ?>"
            placeholder="Enter author name"
            required
        >

        <button type="submit">Save Author</button>

        <a href="index.php">Back</a>

    </form>

</div>

</body>
</html>
