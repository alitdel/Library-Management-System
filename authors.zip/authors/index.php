
<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/db.php';

$stmt = $conn->query("
    SELECT
        authors.author_id,
        authors.author_name,
        authors.created_at,
        COUNT(books.book_id) AS total_books
    FROM authors
    LEFT JOIN books
        ON authors.author_id = books.author_id
    GROUP BY
        authors.author_id,
        authors.author_name,
        authors.created_at
    ORDER BY authors.author_name ASC
");

$authors = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authors Management | Library System</title>
    <link rel="stylesheet" href="../assets/css/library-theme.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px;
            font-family: Arial, sans-serif;
            background: #f5f2fa;
            color: #333;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
        }

        h2 {
            color: #35135f;
            margin-top: 0;
        }

        .top-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            background: #51218a;
            font-size: 14px;
        }

        .btn:hover {
            background: #35135f;
        }

        .edit {
            background: #2878b5;
        }

        .delete {
            background: #c0392b;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 13px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #35135f;
            color: white;
        }

        tr:hover {
            background: #f8f5fc;
        }

        .empty {
            text-align: center;
            padding: 25px;
            color: #777;
        }

        @media (max-width: 650px) {
            body {
                padding: 10px;
            }

            .container {
                padding: 15px;
                overflow-x: auto;
            }

            table {
                min-width: 550px;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <div class="top-actions">
        <h2>Authors Management</h2>

        <div>
            <a href="add.php" class="btn">+ Add Author</a>
            <a href="../dashboard.php" class="btn">Dashboard</a>
            <a href="../logout.php" class="btn">Logout</a>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Author Name</th>
                <th>Total Books</th>
                <th>Date Added</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>

        <?php if (count($authors) > 0): ?>

            <?php foreach ($authors as $index => $author): ?>

                <tr>
                    <td><?= $index + 1 ?></td>

                    <td>
                        <?= htmlspecialchars($author['author_name']) ?>
                    </td>

                    <td>
                        <?= (int)$author['total_books'] ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($author['created_at']) ?>
                    </td>

                    <td>
                        <a
                            href="edit.php?id=<?= (int)$author['author_id'] ?>"
                            class="btn edit"
                        >Edit</a>

                        <a
                            href="delete.php?id=<?= (int)$author['author_id'] ?>"
                            class="btn delete"
                            onclick="return confirm('Are you sure you want to delete this author?');"
                        >Delete</a>
                    </td>
                </tr>

            <?php endforeach; ?>

        <?php else: ?>

            <tr>
                <td colspan="5" class="empty">
                    No authors have been registered yet.
                </td>
            </tr>

        <?php endif; ?>

        </tbody>
    </table>

</div>

</body>
</html>
