
<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/db.php';

$author_id = (int)($_GET['id'] ?? 0);

if ($author_id <= 0) {
    header('Location: index.php');
    exit();
}

try {
    $stmt = $conn->prepare(
        "DELETE FROM authors WHERE author_id = ?"
    );

    $stmt->execute([$author_id]);

    header('Location: index.php?success=deleted');
    exit();

} catch (PDOException $e) {

    if ($e->getCode() === '23000') {
        die(
            'This author cannot be deleted because one or more books are linked to this author. ' .
            '<a href="index.php">Return to Authors Management</a>'
        );
    }

    die(
        'Unable to delete author. Please try again. ' .
        '<a href="index.php">Return to Authors Management</a>'
    );
}
