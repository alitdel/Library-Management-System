
<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/db.php';

$author_id = (int)($_GET['id'] ?? $_POST['author_id'] ?? 0);

if ($author_id <= 0) {
    die('Invalid author ID.');
}

$stmt = $conn->prepare(
    "SELECT * FROM authors WHERE author_id = ?"
);
$stmt->execute([$author_id]);
$author = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$author) {
    die('Author not found.');
}

$author_name = $author['author_name'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $author_name = trim($_POST['author_name'] ?? '');

    if ($author_name === '') {
        $error = 'Please enter the author name.';
    } elseif (mb_strlen($author_name) > 150) {
        $error = 'Author name must not exceed 150 characters.';
    } else {
        try {
            $update = $conn->prepare(
                "UPDATE authors
                 SET author_name = ?
                 WHERE author_id = ?"
            );

            $update->execute([$author_name, $author_id]);

            header('Location: index.php');
            exit();

        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $error = 'Another author already has this name.';
            } else {
                $error = 'Unable to update author. Please try again.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Author | Library System</title>
    <link rel="stylesheet" href="../assets/css/library-theme.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f2fa;
            padding: 30px;
        }

        .container {
            max-width: 500px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        h2 {
            color: #35135f;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button, a {
            padding: 11px 17px;
            background: #51218a;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        a {
            background: #666;
        }

        .error {
            background: #fce8e6;
            color: #a12622;
            padding: 12px;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>Edit Author</h2>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?= $author_id ?>">

        <input
            type="hidden"
            name="author_id"
            value="<?= $author_id ?>"
        >

        <label for="author_name">Author Name</label>

        <input
            type="text"
            id="author_name"
            name="author_name"
            maxlength="150"
            value="<?= htmlspecialchars($author_name) ?>"
            required
        >

        <button type="submit">Update Author</button>

        <a href="index.php">Back</a>

    </form>

</div>

</body>
</html>
